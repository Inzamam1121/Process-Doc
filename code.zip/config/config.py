CONNECTION_STRING = "mysql+mysqlconnector://root:admin123@localhost/PatientDocs"

#Schema of Patient data should be as follows:
'''
Table,Create Table
patient_data,"CREATE TABLE `patient_data` (
  `id` int NOT NULL AUTO_INCREMENT,
  `patient_first_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `patient_last_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `dob` date NOT NULL,
  `request_date` date NOT NULL,
  `old_document` text,
  `new_document` text,
  `old_document_path` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `new_document_path` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `is_deleted` bit(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7512 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci"
'''